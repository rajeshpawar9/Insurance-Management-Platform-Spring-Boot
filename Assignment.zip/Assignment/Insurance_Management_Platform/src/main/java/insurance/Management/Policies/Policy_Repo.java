package insurance.Management.Policies;

import org.springframework.data.jpa.repository.JpaRepository;
public interface Policy_Repo extends JpaRepository<Policy, Integer> {

}
