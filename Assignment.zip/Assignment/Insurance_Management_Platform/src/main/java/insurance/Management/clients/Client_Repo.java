package insurance.Management.clients;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Client_Repo extends JpaRepository<Client, Integer> {

}
