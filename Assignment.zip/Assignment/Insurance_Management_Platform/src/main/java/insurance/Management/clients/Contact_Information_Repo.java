package insurance.Management.clients;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Contact_Information_Repo extends JpaRepository<Contact_information, String> {

}
