package insurance.Management.Claims;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Claim_Repo extends JpaRepository<Claim,Integer> {

}
